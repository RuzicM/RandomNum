//Game values
let min = 1, max = 10, winningNum = getRandomNum(min, max), guessesLeft = 3;


//UI Elements
const game = document.querySelector('#game'),
      minNum = document.querySelector('.min-num'),
      maxNum = document.querySelector('.max-num'),
      guessBtn = document.querySelector('#guess-btn'),
      guessInput = document.querySelector('#guess-input'),
      message = document.querySelector('.message');

      //Assign min and max
      minNum.textContent = min;
      maxNum.textContent = max;
      //Play again eventListener
      game.addEventListener('mousedown', function(e){
        if (e.target.className === 'play-again'){
        
            window.location.reload();
        }
      });

    //Listen for guess
    guessBtn.addEventListener('click', function(){
       let guess =  parseInt(guessInput.value);
        if(isNaN(guess) || guess < min || guess > max){
            setMessage(`Please enter a number between ${min} and ${max}`, 'red');
        }
        //Check if won
        if (guess === winningNum){
            gameOver(true, `${winningNum} is correct , YOU WIN!!`);
        
        }else { 
            //Wrong number
            guessesLeft -= 1;

            if (guessesLeft === 0){
                //Game over lose
                gameOver (false, `Game Over, you lost. The correct numbers was ${winningNum}`)
            }else {
                //Game not over - answer wrong
                //Message
                setMessage(`${guess} is not correct, ${guessesLeft} guesses left`, 'red')
                guessInput.style.borderColor = 'red';

                //Clear input
                guessInput.value = ''
            }
        }
    }); 

    //Game over
    function gameOver(won, msg){
        let color;
        if (won === true){
            color = 'green'
        }else {
            color = 'red';
        }
    //Disable input
        guessInput.style.disabled = 'true';
        guessInput.style.borderColor = color
        setMessage(msg, color);

        //Play Again??
        guessBtn.value = 'Play Again';
        guessBtn.className += 'play-again';
}

function setMessage(msg, color) {
    message.textContent = msg;
    message.style.color = color
    
}
//Get winning num function
function getRandomNum(min, max){
console.log(Math.floor(Math.random() * (max - min + 1) + min))

}